//
//  main.c
//  prog2_20220120
//
//  Created by k21116kk on 2022/01/20.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    int n;
    printf("n? ");
    scanf("%d", &n);
    return 0;
}
